package TestRunner;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import io.cucumber.testng.FeatureWrapper;
import io.cucumber.testng.PickleWrapper;

@io.cucumber.testng.CucumberOptions(features = "src/test/resources/FeatureFileFolder", glue = {
		"StepDefinitions" }, plugin = { "pretty", "json:target/cucumber-reports/Cucumber.json",
				"junit:target/cucumber-reports/Cucumber.xml",
				"html:target/cucumber-reports/spark.html" }, monochrome = false)
public class TestRunner {
	
	
	public static WebDriver driver;
	private io.cucumber.testng.TestNGCucumberRunner testRunner;

	@BeforeClass
	public void setUP() {
		ChromeOptions opt = new ChromeOptions();
		opt.addArguments("start-maximized");
		driver = new ChromeDriver(opt);

		testRunner = new io.cucumber.testng.TestNGCucumberRunner(TestRunner.class);
	}

	@Test(description = "login", dataProvider = "features")
	public void login(PickleWrapper pickle, FeatureWrapper cucumberFeature) {
		testRunner.runScenario(pickle.getPickle());

	}

	@DataProvider(name = "features")
	public Object[] getFeatures() {
		return testRunner.provideScenarios();
	}

	@AfterClass
	public void tearDown() {
		testRunner.finish();
	}

}
